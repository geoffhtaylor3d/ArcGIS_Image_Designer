
from arcpy import Describe
from arcpy.management import ExportMosaicDatasetPaths, Delete
from os import path
from arcpy import da


def get_image_paths(in_mosaic):
    temp_image_table = path.join("in_memory", "temp_image_table")
    ExportMosaicDatasetPaths(in_mosaic, temp_image_table, '', "ALL", "RASTER;ITEM_CACHE")
    images = set([row[0] for row in da.SearchCursor(temp_image_table, "Path")])
    Delete(temp_image_table)
    return images


def get_images_and_stats(in_mosaic):
    # Print extent of the entire mosaic
    desc = Describe(in_mosaic)
    print([desc.extent.XMin, desc.extent.XMax, desc.extent.YMin, desc.extent.YMax])
    images = get_image_paths(in_mosaic)
    s_list = []
    if isinstance(images, str):  # If input is single image set as list
        images = [images]
    # Obtain Extent Coords of each image
    for i in images:
        desc = Describe(i+"/Band_1")
        s_list.append([i, desc.extent.XMin, desc.extent.XMax, desc.extent.YMin, desc.extent.YMax, desc.height,
                       desc.width])
    # Determine Maximum and Minimum coord values from list
    # -- Note: The extent values from the mosaic differ from the actual tiles... esri bug on mosaics probably.
    XMin = min(s_list, key=lambda x: x[1])[1]
    XMax = max(s_list, key=lambda x: x[2])[2]
    YMin = min(s_list, key=lambda x: x[3])[3]
    YMax = max(s_list, key=lambda x: x[4])[4]
    # Detect of each image within the mosaic dataset
    c = 0
    for i in s_list:
        iXMin = i[1]
        iXMax = i[2]
        iYMin = i[3]
        iYMax = i[4]
        # Check for Corners
        if XMin == iXMin and YMin == iYMin:
            s_list[c].append("bl")
        elif XMin == iXMin and YMax == iYMax:
            s_list[c].append("tl")
        elif XMax == iXMax and YMax == iYMax:
            s_list[c].append("tr")
        elif XMax == iXMax and YMin == iYMin:
            s_list[c].append("br")
        # Check for Edges
        elif XMin == iXMin:
            s_list[c].append("l")
        elif YMax == iYMax:
            s_list[c].append("t")
        elif XMax == iXMax:
            s_list[c].append("r")
        elif YMin == iYMin:
            s_list[c].append("b")
        else:
            s_list[c].append("i")
        c += 1
    for i in s_list:
        print(i)


def main():
    get_images_and_stats(in_mosaic)


if __name__ == "__main__":
    debug = True
    if debug:
        in_mosaic = r'C:\Users\geof7015\Documents\ArcGIS\Projects\ArcGIS_Image_Designer\ArcGIS_Image_Designer.gdb\Ortho_Mosaic'
    else:
        from arcpy import GetParameterAsText
        in_mosaic = GetParameterAsText(0)
    main()
